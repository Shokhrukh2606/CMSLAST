<meta property="og:title" content="Title" />
<meta property="og:site_name" content="Site name"/>
<meta property="og:description" content="Description" />
<meta property="og:image" content="Link to your logo" />
<link rel="stylesheet" type="text/css" href="{{ asset('css/bootstrap.min.css') }}">
<link rel="stylesheet" type="text/css" href="{{ asset('css/owl.carousel.min.css') }}">
<link rel="stylesheet" type="text/css" href="{{ asset('css/owl.theme.default.min.css') }}">
<link rel="stylesheet" type="text/css" href="{{ asset('css/index.css') }}">