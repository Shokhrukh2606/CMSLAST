@extends('layouts.app')

@section('content')
    @include($body)
@endsection