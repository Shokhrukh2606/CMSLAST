    
            <p> {{print_r($sliders)}}
            </p>
            <!-- MainSlider  -->
            <section class="mainSlider">

                <div class="mainSlider owl-carousel">

                   
                    <div class="item">
                        <div class="overlay"></div>
                        <div class="content">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-6">  
                                        <div class="description">
                                            <h2>H Type Layer Chicken Cage</h2>
                                            <p>No waste of feed, save feed cost. Reasonable design and excellent ventilation. The sufficient drinking guarantee.
                                            </p>
                                            <div class="moreButton">
                                            <button>
                                                More
                                            </button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="imgWrapper">
                                            <img src="{{asset('images/element2.png')}}">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>      
                    </div>
                    <div class="item">
                        <div class="overlay"></div>
                        <div class="content">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-6">  
                                        <div class="description">
                                            <h2>SS Type Layer Chicken Cage Max</h2>
                                            <p>Guarantee sufficient and well-distributed feed for each tier. Reasonable slope reduces the percentage of egg broken. Manure is completely removed, reducing harmful gases.</p>
                                            <div class="moreButton">
                                            <button>
                                                More
                                            </button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="imgWrapper">
                                            <img src="{{asset('images/element.png')}}">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>      
                    </div>
                   
                </div>
            </section>
  <!-- end mainSLider -->

    <!-- Services -->
    <!-- end Services -->

    <!-- Products -->
    <section class="products">
        <div class="products-slider owl-carousel owl-theme">
            <div class="item">
                <div class="content">
                    <h2>Our <br> Products</h2>
                    <p>1 Construction project management is essential. We're using the most time and iterations efficient life cycles for that.As you may know</p>
                </div>
                <div class="img">
                    <img src="{{asset('images/products.png')}}" alt="products">
                </div>
            </div>
            <div class="item">
                <div class="content">
                    <h2>Our <br> Products</h2>
                    <p>2 Construction project management is essential. We're using the most time and iterations efficient life cycles for that.As you may know</p>
                </div>
                <div class="img">
                    <img src="{{asset("assets/images/products.png")}}" alt="products">
                </div>
            </div>
            <div class="item">
                <div class="content">
                    <h2>Our <br> Products</h2>
                    <p>3 Construction project management is essential. We're using the most time and iterations
                        efficient
                        life cycles for that.As you may know</p>
                </div>
                <div class="img">
                    <img src="{{asset('assets/images/products.png')}}" alt="products">
                </div>
            </div>
        </div>
        <img src="{{asset('images/productsBg.jpg')}}" alt="productsBg" class="products-bg">
    </section>
    <!-- end Products -->


    <!-- Footer -->
    <!-- EndFooter -->