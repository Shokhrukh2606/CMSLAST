<?php

namespace App\Http\Controllers;

use App\Post;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
class LoctechController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $data['title']='good';
        $data['meta']=(object) array('meta_title'=>'get title', 'meta_description'=>'get description');
        $data['body']='home';
        $sliders = Post::where(array('group' => 'sliderMain', 'status' => 'active'))->orderBy('inserted_at', 'DESC')->take(4)->get();
         foreach ($sliders as $item) {
                if ($item->hasMedia('sliderMain')) {
                    $media = $item->getMedia('sliderMain')->reject(function ($item) {
                        return isset($item->id) === false;
                    })
                        ->map(function ($item) {
                            return $item->getFullUrl();
                        });
                    $item->imgPaths = $media;
                    unset($item->media);
                }else{
                    $item->imgPaths=false;
                }
            }
            $data['sliders']=$sliders;
        return view('index', $data);
       // $da=Config::get('site.site_settings');
        // return $da->site_name->en;
        // dd($da);
    }
}