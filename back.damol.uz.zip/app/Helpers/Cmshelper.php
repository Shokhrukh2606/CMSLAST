<?php
use Illuminate\Support\Facades\DB;
if (!function_exists('get_program')) {
    function get_program( $id )
    {
        $data = DB::table('programs')
    
        ->where('id', $id )->get();
    
        return $data->title;
    }
}
if (!function_exists('getLang')) {
    function getLang($passed)
    {
        return json_decode($passed);
    }
}
if (!function_exists('getLangSpec')) {
    function getLangSpec($passed, $lang)
    {
        return json_decode($passed)->$lang;
    }

}
if (!function_exists('getDayOfProgram')) {
    function getDayOfProgram($id)
    {
        $days = [
            "0"=>"Ощибка",
            "1" => "Понедельник",
            "2" => "Вторник", "3" => "Среда"
            , "4" => "Четверг",
            "5" => "Пятница",
            "6" => "Суббота", "7" => "Воскресенье"];
        if ($id){
            return $days[$id];
        }
    }
}
if (!function_exists('langExist')) {
    function langExist($passed, $lang)
    {
        return property_exists($passed, $lang);
    }

}