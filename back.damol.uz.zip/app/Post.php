<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Spatie\MediaLibrary\HasMedia\HasMedia;
use Spatie\MediaLibrary\HasMedia\HasMediaTrait;
use Spatie\MediaLibrary\Models\Media;

class Post extends Model implements HasMedia
{
    //
    use HasMediaTrait;
    protected $table = 'posts';
    /**
     * The primary key associated with the table.
     *
     * @var string
     */
    protected $primaryKey = 'id';
    protected $fillable = ['id', 'group'];
    protected $attributes = [
        'status' => 'active',
    ];

    public static function getPosts(Array $needed, $per_page)
    {
        $default = [
            'group' => ''
        ];
        $q = array_merge($default, $needed);
        $posts = DB::table('posts')->where($q)->paginate($per_page);
        return $posts;
    }
}
