<html prefx="og: http://ogp.me/ns#">
    <head>
        <title><?php echo e($title); ?></title>
        
        <meta property="og:title" content="<?php echo e($meta->meta_title); ?>">
        <meta property="og:description" 
          content="<?php echo e($meta->meta_description); ?>" />
        
        <meta property="og:type" content="website" />
        <meta property="og:url" content="<?php echo e(Request::url()); ?>" />
        <meta property="og:locale" content="uz_UZ" />
        <meta property="og:locale:alternate" content="uz_UZ" />
        <meta property="og:locale:alternate" content="en_EN" />
        <meta property="og:locale:alternate" content="ru_RU" />
        <meta property="og:site_name" content="Loctech" />
        <meta property="og:image" content="<?php echo e(asset('logo.png')); ?>" />
        <meta property="og:image:type" content="image/jpeg" />
        <meta property="og:image:width" content="200" />
        <meta property="og:image:height" content="200" />
        
        <link rel="shortcut icon" href="<?php echo e(asset("favicon.ico")); ?>">
    <?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <body>
                <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="wrapper">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
                <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('layouts.bottomAssets', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html><?php /**PATH D:\OUR COMPANY\back.damol.uz\resources\views/layouts/app.blade.php ENDPATH**/ ?>