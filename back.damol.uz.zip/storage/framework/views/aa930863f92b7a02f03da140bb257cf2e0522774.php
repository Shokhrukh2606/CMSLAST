<div class="topHeader">
        <div class="container">
                <div class="row">
                        <div class="col-md-6">
                                <div class="phones">
                                        <div class="phone">
                                                <img src="<?php echo e(asset("images/icons/phone.svg")); ?>" alt="">+998 99 797 79-79
                                        </div>
                                        <div class="phone">
                                                <!-- <img src="assets/images/icons/phone.svg" alt=""> -->+998 99 797 79-79</div>
                                        </div>
                                </div>
                                <div class="col-md-6">
                                        <div class="langAndSearch">
                                                <div class="search">
                                                        <img src="<?php echo e(asset('images/icons/search.svg')); ?>" alt="search the site loctech.uz">
                                                </div>
                                        <div class="lang">
                                                <div class="mainLang">
                                                        ru
                                                </div>
                                                <ul class="langSwitcher">
                                                        <li>uz</li>
                                                        <li>en</li>
                                                </ul>
                                        </div>
                                </div>
                        </div>
                </div>
        </div>
</div>
<div class="navBar">
        <div class="container">
                <div class="row">
                        <div class="col-md-12">
                                <div class="navs">
                                        <div class="nav">Home</div>
                                        <div class="nav">Products</div>
                                        <div class="nav">Services</div>
                                        <div class="nav">Contacts</div>
                                        <div class="nav">About us</div>
                                </div>
                        </div>
                </div>
        </div>
</div><?php /**PATH D:\VUELAB\back.damol.uz\resources\views/layouts/header.blade.php ENDPATH**/ ?>