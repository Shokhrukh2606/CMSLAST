<script type="text/javascript" src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
			<script type="text/javascript" src="<?php echo e(asset('js/owl.carousel.min.js')); ?>"></script>
			<script type="text/javascript" src="<?php echo e(asset('js/index.js')); ?>"></script>
			<script>
				$('.mainSlider').owlCarousel({
					loop:false,
					rewind:true,
					autoplay:false,
					margin:15,
					nav:false,
					dots: false,
					responsive:{
						0:{
							items:1
						},
						600:{
							items:1
						},
						768:{
							items:1
						},
						1000:{
							items:1
						}
					}
				});

			</script><?php /**PATH D:\VUELAB\back.damol.uz\resources\views/layouts/bottomAssets.blade.php ENDPATH**/ ?>