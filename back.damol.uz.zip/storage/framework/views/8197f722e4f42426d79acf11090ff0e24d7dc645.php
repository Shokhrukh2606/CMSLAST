<h1>
                Настройки
             <a href="<?php echo e(route('posts.create', array('group'=>$_GET['group']))); ?>" class="btn btn-success pull-right">Добавить</a></h1><?php /**PATH D:\VUELAB\back.damol.uz\Modules/Admin\Resources/views/settings/index_top.blade.php ENDPATH**/ ?>