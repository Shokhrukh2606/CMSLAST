<?php $__env->startSection('css'); ?>
    <style>
        table tr:nth-child(even) {
            background-color: #f5f5f5;
        }

        table tr:first-child {
            background-color: initial;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content_header'); ?>
    <?php echo $__env->make('admin::'.$_GET['group'].'.index_top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="table-responsive">
        <table class="table">
            <thead>
            <tr>
                <th>#</th>
                <th>Заголовок</th>
                <th>Анонс</th>
                <th>Статус</th>
                <th>Действие</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->id); ?></td>
                    <td><?php echo e(getLangSpec($item->title, 'ru')); ?></td>
                    <td><?php echo e(getLangSpec($item->short_content, 'ru')); ?></td>
                    <td><?=($item->status == 'active') ? '<span class="label label-success">Активный</span>' : '<span class="label label-warning">Неактивный</span>'?></td>
                    <td>
                        <a href=" <?php echo e(URL::to('/admin/posts/edit/'.$_GET['group'].'/'.$item->id)); ?>" class="btn btn-info">Редактировать</a>
                        <button class="btn btn-danger deleteAction" data-direct="/admin/posts/delete/<?php echo e($item->id); ?>">Удалить
                        </button>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="text-center">
            <?php echo e($posts->appends(['group'=>$_GET['group']])->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function () {
            $(".deleteAction").click(function (e) {
                e.preventDefault()
                var link = '<?php echo e(url('/')); ?>'+$(this).data("direct")
                x = confirm('Вы действительно хотите удалить?');
                if (!x) return false;
                $.ajax({
                    url: link,
                    type: 'POST',
                    data: {"_token": "<?php echo e(csrf_token()); ?>"},
                    success: function (res) {
                        location.reload()
                    },
                    error:function(err){
                        console.log(err)
                    }
                })
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin::index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\VUELAB\back.damol.uz\Modules/Admin\Resources/views/news/index.blade.php ENDPATH**/ ?>