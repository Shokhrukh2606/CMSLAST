<!-- Header -->
    <!-- <div class="topHeader">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="phones">
                        <div class="phone">
                            <img src="assets/icons/phone.svg" alt="">+998 99 797 79-79
                        </div>
                        <div class="phone">
                            <img src="assets/images/icons/phone.svg" alt="">+998 99 797 79-79</div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="langAndSearch">
                            <div class="search">
                                <img src="assets/images/icons/search.svg" alt="search the site loctech.uz">
                            </div>
                            <div class="lang">
                                <div class="mainLang">
                                    ru
                                </div>
                                <ul class="langSwitcher">
                                    <li>uz</li>
                                    <li>en</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </div> -->
            <div class="navBar">
                <div class="container">
                    <div class="row">
                        <div class="col-md-8">
                            <div class="logoNav">
                            <div class="logo">
                                <div>
                                LOCTECH
                                <img src="<?php echo e(asset('images/icons/logo.svg')); ?>">
                                </div>
                            </div>
                            <div class="navs">
                                <div class="nav">Products</div>
                                <div class="nav">Services</div>
                                <div class="nav">Contacts</div>
                            </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="notLogo">
                            
                                <div class="call">+998 97 707 1707</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end Header --><?php /**PATH D:\OUR COMPANY\back.damol.uz\resources\views/layouts/header.blade.php ENDPATH**/ ?>