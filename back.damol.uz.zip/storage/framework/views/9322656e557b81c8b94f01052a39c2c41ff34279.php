<?php $__env->startSection('title', 'Dunyobo\'ylab'); ?>



<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\VUELAB\back.damol.uz\Modules/Admin\Resources/views/index.blade.php ENDPATH**/ ?>