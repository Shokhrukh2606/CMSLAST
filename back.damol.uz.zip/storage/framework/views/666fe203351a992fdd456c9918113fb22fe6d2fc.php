<h1>
                Слайдер (Главный)
             <a href="<?php echo e(route('posts.create', array('group'=>$_GET['group']))); ?>" class="btn btn-success pull-right">Добавить</a></h1><?php /**PATH D:\OUR COMPANY\back.damol.uz\Modules/Admin\Resources/views/sliderMain/index_top.blade.php ENDPATH**/ ?>