<section class="mainSlider">

    <div class="mainSlider owl-carousel">

        <div class="item">
            <div class="overlay"></div>
            <div class="content">
                <h2>NEST IS THE BEST ONE</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Hic, qui, iure. Ipsum minima quo provident sed aut, vitae corporis quam! Accusamus tempore eum praesentium tenetur iure distinctio rem quae quasi.</p>
                <button>
                    More
                </button>
            </div>		
        </div>
        <div class="item">
            <div class="overlay"></div>
            <div class="content">
                <h2>NEST IS THE BEST ONE</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Hic, qui, iure. Ipsum minima quo provident sed aut, vitae corporis quam! Accusamus tempore eum praesentium tenetur iure distinctio rem quae quasi.</p>
                <button>
                    More
                </button>
            </div>		
        </div>
        <div class="item">
            <div class="overlay"></div>
            <div class="content">
                <h2>NEST IS THE BEST ONE</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Hic, qui, iure. Ipsum minima quo provident sed aut, vitae corporis quam! Accusamus tempore eum praesentium tenetur iure distinctio rem quae quasi.</p>
                <button>
                    More
                </button>
            </div>		
        </div>
    </div>
</section>
<?php echo e(__('messages.failed')); ?><?php /**PATH D:\VUELAB\back.damol.uz\resources\views/home.blade.php ENDPATH**/ ?>