<?php
$spec_langs = ['ru', 'uz', 'oz', 'en'];
$title = getLang($post->title);
$short_content = getLang($post->short_content);
$content = getLang($post->content);
?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('plugins/dropzone/dist/dropzone.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('js/datepicker/bootstrap-datepicker.min.js')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <ul class="nav nav-pills">
        <li class="active"><a data-toggle="pill" href="#ru">Русские</a></li>
        <li><a data-toggle="pill" href="#uz">Ўзбекча</a></li>
        <li><a data-toggle="pill" href="#oz">O'zbekcha</a></li>
        <li><a data-toggle="pill" href="#en">English</a></li>
        <li class="pull-right">
            <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#mediaModal">Медиа
            </button>
        </li>
    </ul>
    <form method="POST" action="<?php echo e(route('posts.update', [$post->id, $post->group])); ?>">
        <?php echo csrf_field(); ?>
        <div class="tab-content">
            <?php $__currentLoopData = $spec_langs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div id="<?php echo e($lg); ?>" class="tab-pane fade in <?php echo e(($lg=='ru')?'active':''); ?>">
                    <input type="hidden" name="group" value="<?php echo e($post->group); ?>">
                    <div class="form-group">
                        <label for="usr">Заголовок</label>
                        <input type="text" name="title[<?php echo e($lg); ?>]" class="form-control" value="<?php echo e($title->$lg); ?>"
                               id="title_<?php echo e($lg); ?>">
                    </div>
                    <div class="form-group">
                        <label for="short_content_<?php echo e($lg); ?>">Анонс</label>
                        <textarea class="form-control" rows="5" name="short_content[<?php echo e($lg); ?>]" cols="30" rows="10"
                                  id="short_content_<?php echo e($lg); ?>"><?php echo e($short_content->$lg); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="content_<?php echo e($lg); ?>">Контент</label>
                        <textarea name="content[<?php echo e($lg); ?>]" cols="30" rows="10"
                                  id="content_<?php echo e($lg); ?>"><?php echo e($content->$lg); ?></textarea>
                    </div>
                </div>
                
                
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        <div class="form-group">
            <label for="usr">Слаг</label>
            <input type="text" name="alias" class="form-control"
                   id="alias" value="<?php echo e($post->alias); ?>">
        </div>
        <div class="form-group">
            <label for="usr">Дата</label>
            <input type="text" name="inserted_at" class="form-control datepicker"
                   id="alias" value="<?php echo e(date('d.m.Y', strtotime($post->inserted_at))); ?>">
        </div>
        <div class="form-group">
            <label for="status">Статус</label>
            <select class="form-control" id="status" name="status">
                
                <option selected value="active">Активный</option>
                <option value="inactive">Неактивный</option>
            </select>
        </div>
        <button class="btn btn-info pull-right">Сохранить</button>
        <div class="clearfix"></div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('vendor/ckeditor/ckeditor.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/dropzone/dist/dropzone.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/ckeditor/adapters/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.synctranslit.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datepicker/bootstrap-datepicker.min.js')); ?>"></script>
    <script>
        $('.datepicker').datepicker({"format":"dd.mm.yyyy", "autoclose":true}).datepicker();
        var pID = '<?php echo e($post->id); ?>'
        var baseUrl = '<?php echo e(url('/')); ?>'
        var options = {
            
                    
                    
                    
                    
            filebrowserImageBrowseUrl: '<?php echo e(url("/filemanager?type=Images")); ?>',
            filebrowserImageUploadUrl: '<?php echo e(url("/filemanager/upload?type=Images&_token=").csrf_token()); ?>',
            filebrowserBrowseUrl: '<?php echo e(url("/filemanager?type=Files")); ?>',
            filebrowserUploadUrl: '<?php echo e(url("/filemanager/upload?type=Files&_token=").csrf_token()); ?>'
        };
        <?php $__currentLoopData = $spec_langs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        $('textarea#content_<?php echo e($lg); ?>').ckeditor(options);
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        $('#title_ru').syncTranslit({destination: 'alias'});
        var uploadedDocumentMap = {}
        Dropzone.options.documentDropzone = {
            url: '<?php echo e(route('posts.mediaAdd', ['id'=>$post->id, 'group'=>$post->group])); ?>',
            maxFilesize: 2, // MB
            addRemoveLinks: true,
            headers: {
                'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
            },
            success: function (file, response) {
            },
            queuecomplete: function () {

            },
            removedfile: function (file) {
                x = confirm('Do you want to delete?');
                if (!x) return false;
                var name = ''
                var uniqueID = file.imgID
                if (typeof file.file_name !== 'undefined') {
                    name = file.file_name
                } else {
                    name = uploadedDocumentMap[file.file_name]
                }
                var removed = $('form').find('input[name="document[]"][value="' + name + '"]');
                $.post(baseUrl + '/admin/posts/mediaDelete', {
                    imgid: uniqueID,
                    "_token": "<?php echo e(csrf_token()); ?>",
                    'post_id': pID
                }).then(function (res) {
                    if (res.success) {
                        file.previewElement.remove()
                        removed.remove()
                    }
                })
            },
            init: function () {
                        <?php if(isset($mediaItems) && $mediaItems): ?>
                var files =
                <?php echo json_encode($mediaItems); ?>

                    for (var i in files) {
                    var file = files[i]
                    this.options.addedfile.call(this, file)
                    file.previewElement.classList.add('dz-complete')
                    file.previewElement.querySelector("img").src = file.imgPath;

                    $('form').append('<input type="hidden" name="document[]" value="' + file.name + '" imgid="' + file.imgID + '">')
                }
                <?php endif; ?>
            }
        }
        // var ru_t=
        // $('textarea#ru_form').ckeditor(options);
        // // var uz_t=
        // $('textarea#uz_form').ckeditor(options);
        // // var oz_t=
        // $('textarea#oz_form').ckeditor(options);
        // // var en_t=
        // $('textarea#en_form').ckeditor(options);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin::index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OUR COMPANY\back.damol.uz\Modules/Admin\Resources/views/sliderMain/edit.blade.php ENDPATH**/ ?>