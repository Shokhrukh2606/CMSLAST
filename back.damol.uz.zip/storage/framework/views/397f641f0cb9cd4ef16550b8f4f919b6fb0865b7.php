<div id="mediaModal" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Медиа</h4>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route("posts.mediaAdd", [$post->id])); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="document">Documents</label>
                        <div class="needsclick dropzone" id="document-dropzone">
                        </div>
                    </div>
                </form>



















            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>

    </div>
</div>
<style>
    #mediaModal .modal-body{
        min-height: 75vh;
    }
    #mediaModal .modal-dialog{
        min-width: 70%;
    }
    #mediaModal    .dropzone .dz-preview .dz-image img {
        display: block;
        width: 150px;
        height: 150px;
        object-fit: cover;
    }
</style><?php /**PATH D:\OUR COMPANY\back.damol.uz\Modules/Admin\Resources/views/partials/footer.blade.php ENDPATH**/ ?>