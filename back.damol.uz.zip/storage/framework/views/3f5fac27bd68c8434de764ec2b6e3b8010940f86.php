<footer>
<h1>Footer</h1>
    
</footer><?php /**PATH D:\VUELAB\back.damol.uz\resources\views/layouts/footer.blade.php ENDPATH**/ ?>