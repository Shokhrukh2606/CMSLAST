# How to contribute

Thank you for taking the time to review jQuery Timepicker and submit modifications. Please submit a Pull Request using the `devel` branch as base.
