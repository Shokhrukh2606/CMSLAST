<?php
symlink('/home/damoluz/back.damol.uz/public/storage', '/home/damoluz/back.damol.uz/storage');
?>