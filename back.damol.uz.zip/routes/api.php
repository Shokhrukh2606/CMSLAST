<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
// Route::resource('/news', 'FnewsController');
// Route::get('/premiere', 'DunyoController@premiere_all');
// Route::get('/premiere/{id}', 'DunyoController@premiere_show');
// Route::get('/gallery', 'DunyoController@gallery_all');
// Route::get('/gallery/{id}', 'DunyoController@gallery_show');
// Route::get('/pros', 'DunyoController@pros_all');
// Route::get('/pros/{id}', 'DunyoController@pros_show');
// Route::get('/trips', 'DunyoController@trips_all');
// Route::get('/trips/{id}', 'DunyoController@trips_show');
// Route::get('/settings', 'DunyoController@settings');
// FRONT PROS
// Route::get('protoday', 'DunyoController@pro_today');
// FRONT PROS
// Route::middleware('auth:api')->get('/user', function (Request $request) {
//     return $request->user();
// });
