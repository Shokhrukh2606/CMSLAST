<?php

return [
    'name' => 'Admin'
];
