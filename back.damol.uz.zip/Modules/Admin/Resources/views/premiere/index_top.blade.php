<h1>
                Премьеры
             <a href="{{route('posts.create', array('group'=>$_GET['group']))}}" class="btn btn-success pull-right">Добавить</a></h1>